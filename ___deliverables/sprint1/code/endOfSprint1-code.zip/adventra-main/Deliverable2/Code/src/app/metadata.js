export const metadata = {
  title: "Adventra",
  description: "Connect with your friends and family",
};

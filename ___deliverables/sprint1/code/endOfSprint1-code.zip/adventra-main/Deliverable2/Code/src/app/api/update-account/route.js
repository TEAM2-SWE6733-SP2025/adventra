import { prisma } from "@/app/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/route";

export async function PUT(req) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return new Response(JSON.stringify({ error: "Not authenticated" }), {
      status: 401,
    });
  }

  const data = await req.json();
  const userEmail = session.user.email;

  try {
    const updatedUser = await prisma.user.update({
      where: { email: userEmail },
      data: {
        profile: {
          upsert: {
            create: {
              hobbies: data.hobbies,
              favouriteFood: data.favouriteFood,
              interestedPlaces: data.interestedPlaces,
              facebook: data.facebook,
              twitter: data.twitter,
              instagram: data.instagram,
              linkedin: data.linkedin,
            },
            update: {
              hobbies: data.hobbies,
              favouriteFood: data.favouriteFood,
              interestedPlaces: data.interestedPlaces,
              facebook: data.facebook,
              twitter: data.twitter,
              instagram: data.instagram,
              linkedin: data.linkedin,
            },
          },
        },
      },
      include: { profile: true },
    });

    return new Response(JSON.stringify(updatedUser));
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: "Failed to update" }), {
      status: 500,
    });
  }
}

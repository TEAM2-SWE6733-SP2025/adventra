-- AlterTable
ALTER TABLE "User" ADD COLUMN     "instagramLink" TEXT,
ADD COLUMN     "linkedInLink" TEXT,
ADD COLUMN     "twitterLink" TEXT;
